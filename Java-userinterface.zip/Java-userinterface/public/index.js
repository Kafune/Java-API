$( document ).ready(function() {
    var tempCount = 0;
    var useValue;
    var history = [];

    $('.getCurrentTemp').click(function() {
        $.ajax({
            url : 'http://192.168.99.121:8080/temperature/currentjson',
            method : 'GET',
            async : 'false',
            success : function(data) {
                $('#gethistory').append('Huidige temperatuur is: '+data.temperature+'<br>');
                useValue = data.temperature;
                history.push(useValue);
            },
            error : function() {
                alert ('niet gelukt')
            }
        });
    });

    $('.getHistory').click(function() {
        // jQuery.grep(history, function(){
        //     $('#gethistory').append(history+', ');
        // });

        history.splice($.inArray(useValue, history), 1);

        if(history.length === 0) {
            alert('Geen temperatuur beschikbaar!');
        } else {
            var lastHistory = history[history.length-1];
            tempCount ++;
            $('#gethistory').append('Temperatuur '+tempCount+': ' +lastHistory+' <br>');
        }


    });



});